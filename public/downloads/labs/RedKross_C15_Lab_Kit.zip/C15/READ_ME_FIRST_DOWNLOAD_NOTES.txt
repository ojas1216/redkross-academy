Private keys (*.key) are never shipped in the download. Before the Module 6 TLS lab, run the
Module 5 PKI lab once to generate the lab CA, intermediate and server keys in pki/:
  sh m05_pki_lab.sh        (Linux/macOS, or Git Bash on Windows; needs OpenSSL 3)
Then: python m06_tls.py
